# Nuage-openstack-upgrade-scripts

## Warning

The scripts in this package should only be used by qualified technical support staff and according to the guidelines in
the Nuage User Documentation. Unappropriate use may change data on both OpenStack Controller and VSD platform and result
in inconsistent or failing system.
